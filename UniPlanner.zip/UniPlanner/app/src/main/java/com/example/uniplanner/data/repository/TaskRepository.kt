package com.example.uniplanner.data.repository

import com.example.uniplanner.data.local.Task
import com.example.uniplanner.data.local.TaskDao
import kotlinx.coroutines.flow.Flow

/**
 * Repository - Single Source of Truth for Task data.
 *
 * Why Repository Pattern?
 * 1. Abstracts data sources from ViewModel
 * 2. ViewModel doesn't know if data comes from Room, Network, or Cache
 * 3. Easy to add new data sources (e.g., sync with server) later
 * 4. Centralized data logic - no duplication
 *
 * @param taskDao Room DAO injected via constructor (Dependency Injection)
 */
class TaskRepository(private val taskDao: TaskDao) {

    // ============== READ OPERATIONS ==============

    /**
     * Get tasks filtered by search query.
     * Returns Flow for reactive updates.
     *
     * Flow will automatically emit new list when:
     * - New task is inserted
     * - Task is updated
     * - Task is deleted
     */
    fun getTasks(searchQuery: String): Flow<List<Task>> {
        return taskDao.getTasks(searchQuery)
    }

    /**
     * Get single task by ID.
     * Used in Edit Task screen.
     */
    fun getTaskById(taskId: Int): Flow<Task?> {
        return taskDao.getTaskById(taskId)
    }

    /**
     * Get tasks due within time range.
     * Used by WorkManager for notifications.
     */
    suspend fun getTasksDueBetween(startTime: Long, endTime: Long): List<Task> {
        return taskDao.getTasksDueBetween(startTime, endTime)
    }

    // ============== WRITE OPERATIONS ==============

    /**
     * Insert new task.
     * Returns the generated ID.
     */
    suspend fun insertTask(task: Task): Long {
        return taskDao.insertTask(task)
    }

    /**
     * Update existing task.
     */
    suspend fun updateTask(task: Task) {
        taskDao.updateTask(task)
    }

    /**
     * Delete task.
     * Used by Swipe-to-Delete feature.
     */
    suspend fun deleteTask(task: Task) {
        taskDao.deleteTask(task)
    }
}