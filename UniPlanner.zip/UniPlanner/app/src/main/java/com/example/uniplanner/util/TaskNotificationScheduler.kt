package com.example.uniplanner.util

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.uniplanner.data.local.Task
import java.util.concurrent.TimeUnit

/**
 * Helper class to schedule/cancel task notifications using WorkManager.
 */
object TaskNotificationScheduler {

    // 24 hours before deadline (bản chính thức)
    private const val NOTIFICATION_LEAD_TIME_MS = 24 * 60 * 60 * 1000L

    /**
     * Schedule notification for a specific task.
     *
     * @param context Application or Activity context
     * @param task Task to schedule reminder for
     */
    fun schedule(context: Context, task: Task) {
        // Chỉ schedule nếu task có dueDate và chưa hoàn thành
        if (task.dueDate == null || task.isCompleted) {
            cancel(context, task.id)
            return
        }

        val now = System.currentTimeMillis()
        val notificationTime = task.dueDate!! - NOTIFICATION_LEAD_TIME_MS
        var delayMillis = notificationTime - now

        // 🔥 Để TEST: nếu delay <= 0 thì đặt tối thiểu 10s
        if (delayMillis <= 0L) {
            delayMillis = 10_000L // 10 seconds
        }

        val inputData = Data.Builder()
            .putInt(NotificationWorker.KEY_TASK_ID, task.id.toInt())
            .putString(NotificationWorker.KEY_TASK_TITLE, task.title)
            .build()

        val workRequest = OneTimeWorkRequestBuilder<NotificationWorker>()
            .setInputData(inputData)
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .addTag("task_notification_${task.id}")
            .build()

        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(
                "task_notification_${task.id}",
                ExistingWorkPolicy.REPLACE,
                workRequest
            )
    }

    /**
     * Cancel scheduled notification for a task.
     */
    fun cancel(context: Context, taskId: Int) {
        WorkManager.getInstance(context.applicationContext)
            .cancelUniqueWork("task_notification_$taskId")
    }

    /**
     * DEBUG: schedule a test notification after 10 seconds.
     * Dùng để kiểm tra WorkManager + notification pipeline có hoạt động không.
     */
    fun scheduleDebugNotification(context: Context) {
        val data = Data.Builder()
            .putInt(NotificationWorker.KEY_TASK_ID, 999)
            .putString(NotificationWorker.KEY_TASK_TITLE, "Debug notification")
            .build()

        val request = OneTimeWorkRequestBuilder<NotificationWorker>()
            .setInputData(data)
            .setInitialDelay(10, TimeUnit.SECONDS)
            .addTag("debug_notification")
            .build()

        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(
                "debug_notification",
                ExistingWorkPolicy.REPLACE,
                request
            )
    }
}
