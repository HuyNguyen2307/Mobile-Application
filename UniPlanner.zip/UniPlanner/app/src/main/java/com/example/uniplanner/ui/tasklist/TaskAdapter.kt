// ui/tasklist/TaskAdapter.kt
package com.example.uniplanner.ui.tasklist

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.uniplanner.R
import com.example.uniplanner.data.local.Task
import com.example.uniplanner.databinding.ItemTaskBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RecyclerView Adapter using ListAdapter for efficient updates.
 */
class TaskAdapter(
    private val onTaskClick: (Task) -> Unit,
    private val onTaskCheckedChange: (Task, Boolean) -> Unit
) : ListAdapter<Task, TaskAdapter.TaskViewHolder>(TaskDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TaskViewHolder(
        private val binding: ItemTaskBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onTaskClick(getItem(position))
                }
            }

            binding.checkboxCompleted.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val task = getItem(position)
                    onTaskCheckedChange(task, binding.checkboxCompleted.isChecked)
                }
            }
        }

        fun bind(task: Task) {
            binding.apply {
                // Title with strikethrough if completed
                textTitle.text = task.title
                if (task.isCompleted) {
                    textTitle.paintFlags = textTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                    textTitle.alpha = 0.5f
                } else {
                    textTitle.paintFlags = textTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                    textTitle.alpha = 1.0f
                }

                // Checkbox state
                checkboxCompleted.isChecked = task.isCompleted

                // Description
                if (task.description.isNotBlank()) {
                    textDescription.text = task.description
                    textDescription.visibility = View.VISIBLE
                } else {
                    textDescription.visibility = View.GONE
                }

                // Due date
                if (task.dueDate != null) {
                    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    textDueDate.text = dateFormat.format(Date(task.dueDate))
                    iconDueDate.visibility = View.VISIBLE
                    textDueDate.visibility = View.VISIBLE

                    // Highlight overdue tasks
                    val isOverdue = task.dueDate < System.currentTimeMillis() && !task.isCompleted
                    if (isOverdue) {
                        textDueDate.setTextColor(
                            ContextCompat.getColor(root.context, R.color.error)
                        )
                    } else {
                        textDueDate.setTextColor(
                            ContextCompat.getColor(root.context, R.color.on_surface)
                        )
                    }
                } else {
                    iconDueDate.visibility = View.GONE
                    textDueDate.visibility = View.GONE
                }

                // Priority badge
                setPriorityBadge(task.priority)
            }
        }

        private fun setPriorityBadge(priority: Int) {
            val context = binding.root.context
            binding.textPriority.apply {
                when (priority) {
                    2 -> {
                        text = context.getString(R.string.priority_high)
                        setBackgroundColor(ContextCompat.getColor(context, R.color.priority_high))
                        visibility = View.VISIBLE
                    }
                    1 -> {
                        text = context.getString(R.string.priority_medium)
                        setBackgroundColor(ContextCompat.getColor(context, R.color.priority_medium))
                        visibility = View.VISIBLE
                    }
                    else -> {
                        visibility = View.GONE
                    }
                }
            }
        }
    }

    class TaskDiffCallback : DiffUtil.ItemCallback<Task>() {
        override fun areItemsTheSame(oldItem: Task, newItem: Task): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Task, newItem: Task): Boolean {
            return oldItem == newItem
        }
    }
}