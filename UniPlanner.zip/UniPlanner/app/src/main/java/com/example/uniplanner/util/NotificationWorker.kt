package com.example.uniplanner.util

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.uniplanner.MainActivity
import com.example.uniplanner.R
import com.example.uniplanner.UniPlannerApplication

/**
 * Worker class that sends notification for task deadline.
 *
 * Architecture Decision: Using CoroutineWorker because:
 * 1. Supports suspend functions (can query database)
 * 2. Automatically runs on background thread
 * 3. Handles cancellation properly
 *
 * WorkManager guarantees this will run even if:
 * - App is closed
 * - Device is restarted
 * - Device is in Doze mode (with some delay)
 */
class NotificationWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        // Get task details from input data
        val taskId = inputData.getInt(KEY_TASK_ID, -1)
        val taskTitle = inputData.getString(KEY_TASK_TITLE) ?: "Task"

        if (taskId == -1) {
            return Result.failure()
        }

        // Show notification
        showNotification(taskId, taskTitle)

        return Result.success()
    }

    /**
     * Display notification to user.
     */
    private fun showNotification(taskId: Int, taskTitle: String) {
        // Check permission for Android 13+
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        // Intent to open app when notification is tapped
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            taskId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build notification
        val notification = NotificationCompat.Builder(context, UniPlannerApplication.Companion.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Task Due Tomorrow!")
            .setContentText(taskTitle)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        // Show notification
        NotificationManagerCompat.from(context).notify(taskId, notification)
    }

    companion object {
        const val KEY_TASK_ID = "task_id"
        const val KEY_TASK_TITLE = "task_title"
    }
}