// ui/addedittask/AddEditTaskActivity.kt
package com.example.uniplanner.ui.addedittask

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.uniplanner.R
import com.example.uniplanner.UniPlannerApplication
import com.example.uniplanner.data.local.Task
import com.example.uniplanner.data.repository.TaskRepository
import com.example.uniplanner.databinding.ActivityAddEditTaskBinding
import com.example.uniplanner.ui.tasklist.TaskViewModel
import com.example.uniplanner.ui.tasklist.TaskViewModelFactory
import com.example.uniplanner.util.TaskNotificationScheduler
import com.google.android.material.datepicker.MaterialDatePicker
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddEditTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditTaskBinding

    private val viewModel: TaskViewModel by viewModels {
        val app = application as UniPlannerApplication
        val repository = TaskRepository(app.database.taskDao())
        TaskViewModelFactory(repository)
    }

    // Task being edited (null if creating new task)
    private var editingTask: Task? = null

    // Selected due date (null if no date selected)
    private var selectedDueDate: Long? = null

    // Permission launcher for notifications (Android 13+)
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Permission granted, notification will be scheduled when task is saved
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestNotificationPermission()
        setupDatePicker()
        setupPriorityToggle()
        setupSaveButton()
        loadTaskIfEditing()
    }

    /**
     * Request notification permission for Android 13+
     */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    /**
     * Setup Material DatePicker for due date selection.
     */
    private fun setupDatePicker() {
        binding.editTextDueDate.setOnClickListener {
            showDatePicker()
        }

        binding.layoutDueDate.setEndIconOnClickListener {
            showDatePicker()
        }
    }

    private fun showDatePicker() {
        val datePicker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select Due Date")
            .setSelection(selectedDueDate ?: MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        datePicker.addOnPositiveButtonClickListener { selection ->
            selectedDueDate = selection
            updateDueDateDisplay()
        }

        datePicker.show(supportFragmentManager, "DATE_PICKER")
    }

    private fun updateDueDateDisplay() {
        if (selectedDueDate != null) {
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            binding.editTextDueDate.setText(dateFormat.format(Date(selectedDueDate!!)))
        } else {
            binding.editTextDueDate.setText("")
        }
    }

    /**
     * Setup priority toggle group.
     */
    private fun setupPriorityToggle() {
        // Default is Medium (already set in XML)
    }

    /**
     * Get selected priority from toggle group.
     */
    private fun getSelectedPriority(): Int {
        return when (binding.toggleGroupPriority.checkedButtonId) {
            R.id.buttonHigh -> 2
            R.id.buttonMedium -> 1
            else -> 0
        }
    }

    /**
     * Set priority toggle based on priority value.
     */
    private fun setPriorityToggle(priority: Int) {
        val buttonId = when (priority) {
            2 -> R.id.buttonHigh
            1 -> R.id.buttonMedium
            else -> R.id.buttonLow
        }
        binding.toggleGroupPriority.check(buttonId)
    }

    /**
     * Setup save button click listener.
     */
    private fun setupSaveButton() {
        binding.buttonSave.setOnClickListener {
            saveTask()
        }
    }

    /**
     * Validate and save task.
     */
    private fun saveTask() {
        val title = binding.editTextTitle.text.toString().trim()
        val description = binding.editTextDescription.text.toString().trim()

        // Validation
        if (title.isEmpty()) {
            binding.layoutTitle.error = getString(R.string.error_title_required)
            return
        }

        binding.layoutTitle.error = null

        // Create or update task
        val task = if (editingTask != null) {
            // Update existing task
            editingTask!!.copy(
                title = title,
                description = description,
                dueDate = selectedDueDate,
                priority = getSelectedPriority()
            )
        } else {
            // Create new task
            Task(
                title = title,
                description = description,
                dueDate = selectedDueDate,
                priority = getSelectedPriority()
            )
        }

        // Save to database
        if (editingTask != null) {
            viewModel.updateTask(task)
        } else {
            viewModel.insertTask(task)
        }

        // Schedule notification
        TaskNotificationScheduler.schedule(this, task)

        // Show success message and close
        Toast.makeText(this, R.string.task_saved, Toast.LENGTH_SHORT).show()
        finish()
    }

    /**
     * Load task data if editing existing task.
     */
    private fun loadTaskIfEditing() {
        val taskId = intent.getIntExtra(EXTRA_TASK_ID, -1)

        if (taskId != -1) {
            // We're editing an existing task
            title = getString(R.string.edit_task)

            lifecycleScope.launch {
                repeatOnLifecycle(Lifecycle.State.STARTED) {
                    viewModel.getTaskById(taskId).collect { task ->
                        task?.let {
                            editingTask = it
                            populateFields(it)
                        }
                    }
                }
            }
        } else {
            title = getString(R.string.add_task)
        }
    }

    /**
     * Populate form fields with task data.
     */
    private fun populateFields(task: Task) {
        binding.editTextTitle.setText(task.title)
        binding.editTextDescription.setText(task.description)

        selectedDueDate = task.dueDate
        updateDueDateDisplay()

        setPriorityToggle(task.priority)
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
    }
}