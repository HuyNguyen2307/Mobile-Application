package com.example.uniplanner.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Task Entity - Represents a single task in the database.
 *
 * @Entity annotation tells Room this is a database table.
 * Each property becomes a column in the table.
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val title: String,

    val description: String = "",

    /**
     * Due date stored as Unix timestamp (milliseconds).
     * Using Long because:
     * 1. Room doesn't support LocalDateTime directly
     * 2. Easy to compare and calculate time differences
     * 3. Timezone independent
     *
     * Null means no deadline set.
     */
    val dueDate: Long? = null,

    val priority: Int = 1,

    val isCompleted: Boolean = false,

    /**
     * Timestamp when task was created.
     * Useful for sorting "recently added" tasks.
     */
    val createdAt: Long = System.currentTimeMillis()
)