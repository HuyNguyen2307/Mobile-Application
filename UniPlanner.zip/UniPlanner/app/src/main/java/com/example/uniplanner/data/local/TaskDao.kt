package com.example.uniplanner.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) for Task operations.
 *
 * Architecture Decision:
 * - READ operations return Flow<T> for reactive updates
 * - WRITE operations are suspend functions for background execution
 */
@Dao
interface TaskDao {

    // ============== READ OPERATIONS ==============

    /**
     * Get all tasks with optional search filter.
     *
     * Why Flow?
     * - Automatically emits new data when database changes
     * - UI updates in real-time without manual refresh
     * - Lifecycle-aware (stops when UI is destroyed)
     *
     * The '%%' around searchQuery enables partial matching:
     * - Search "math" will match "Mathematics", "math homework", etc.
     */
    @Query("""
        SELECT * FROM tasks 
        WHERE title LIKE '%' || :searchQuery || '%' 
           OR description LIKE '%' || :searchQuery || '%'
        ORDER BY isCompleted ASC, dueDate ASC, createdAt DESC
    """)
    fun getTasks(searchQuery: String): Flow<List<Task>>

    /**
     * Get a single task by ID.
     * Used when editing an existing task.
     */
    @Query("SELECT * FROM tasks WHERE id = :taskId")
    fun getTaskById(taskId: Int): Flow<Task?>

    /**
     * Get tasks due within a time range.
     * Used by WorkManager to find tasks needing notifications.
     */
    @Query("""
        SELECT * FROM tasks 
        WHERE dueDate BETWEEN :startTime AND :endTime 
          AND isCompleted = 0
    """)
    suspend fun getTasksDueBetween(startTime: Long, endTime: Long): List<Task>

    // ============== WRITE OPERATIONS ==============

    /**
     * Insert a new task or replace if ID exists.
     * Returns the row ID of the inserted task.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task): Long

    /**
     * Update an existing task.
     */
    @Update
    suspend fun updateTask(task: Task)

    /**
     * Delete a task.
     * Used by "Swipe to Delete" feature.
     */
    @Delete
    suspend fun deleteTask(task: Task)
}