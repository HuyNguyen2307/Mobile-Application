// MainActivity.kt
package com.example.uniplanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uniplanner.data.local.Task
import com.example.uniplanner.data.repository.TaskRepository
import com.example.uniplanner.databinding.ActivityMainBinding
import com.example.uniplanner.ui.addedittask.AddEditTaskActivity
import com.example.uniplanner.ui.tasklist.SwipeToDeleteCallback
import com.example.uniplanner.ui.tasklist.TaskAdapter
import com.example.uniplanner.ui.tasklist.TaskViewModel
import com.example.uniplanner.ui.tasklist.TaskViewModelFactory
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import com.example.uniplanner.util.TaskNotificationScheduler

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    private val viewModel: TaskViewModel by viewModels {
        val app = application as UniPlannerApplication
        val repository = TaskRepository(app.database.taskDao())
        TaskViewModelFactory(repository)
    }

    private lateinit var taskAdapter: TaskAdapter
    private var recentlyDeletedTask: Task? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //TaskNotificationScheduler.scheduleDebugNotification(this)(bugtest)

        setupRecyclerView()
        setupSearchView()
        setupFab()
        observeTasks()
    }

    private fun setupRecyclerView() {
        taskAdapter = TaskAdapter(
            onTaskClick = { task ->
                val intent = Intent(this, AddEditTaskActivity::class.java)
                intent.putExtra(AddEditTaskActivity.EXTRA_TASK_ID, task.id)
                startActivity(intent)
            },
            onTaskCheckedChange = { task, isChecked ->
                viewModel.updateTask(task.copy(isCompleted = isChecked))
            }
        )

        binding.recyclerViewTasks.apply {
            adapter = taskAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
        }

        val swipeCallback = SwipeToDeleteCallback(this) { position ->
            val task = taskAdapter.currentList[position]
            deleteTaskWithUndo(task)
        }
        ItemTouchHelper(swipeCallback).attachToRecyclerView(binding.recyclerViewTasks)
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                binding.searchView.clearFocus()
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.onSearchQueryChanged(newText.orEmpty())
                return true
            }
        })
    }

    private fun setupFab() {
        binding.fabAddTask.setOnClickListener {
            val intent = Intent(this, AddEditTaskActivity::class.java)
            startActivity(intent)
        }
    }

    private fun observeTasks() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.tasks.collect { tasks ->
                    taskAdapter.submitList(tasks)
                    binding.layoutEmpty.visibility = if (tasks.isEmpty()) {
                        View.VISIBLE
                    } else {
                        View.GONE
                    }
                }
            }
        }
    }

    private fun deleteTaskWithUndo(task: Task) {
        recentlyDeletedTask = task
        viewModel.deleteTask(task)

        Snackbar.make(
            binding.root,
            getString(R.string.task_deleted),
            Snackbar.LENGTH_LONG
        ).setAction(getString(R.string.undo)) {
            recentlyDeletedTask?.let { deletedTask ->
                viewModel.insertTask(deletedTask)
            }
        }.show()
    }
}
private const val REQUEST_POST_NOTIFICATIONS = 1001
