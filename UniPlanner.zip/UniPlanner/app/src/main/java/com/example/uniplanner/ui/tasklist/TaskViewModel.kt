// ui/tasklist/TaskViewModel.kt
package com.example.uniplanner.ui.tasklist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.uniplanner.data.local.Task
import com.example.uniplanner.data.repository.TaskRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel for Task List screen.
 *
 * Responsibilities:
 * 1. Hold UI state (survives configuration changes)
 * 2. Handle search logic with flatMapLatest
 * 3. Execute database operations via Repository
 */
@OptIn(ExperimentalCoroutinesApi::class)
class TaskViewModel(private val repository: TaskRepository) : ViewModel() {

    // ============== SEARCH STATE ==============

    private val _searchQuery = MutableStateFlow("")

    // ============== TASK LIST STATE ==============

    /**
     * Main task list - combines search query with database.
     * flatMapLatest cancels previous query when new search term arrives.
     */
    val tasks: StateFlow<List<Task>> = _searchQuery
        .flatMapLatest { query ->
            repository.getTasks(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // ============== USER ACTIONS ==============

    /**
     * Called when user types in SearchView.
     */
    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    /**
     * Get single task by ID for editing.
     */
    fun getTaskById(taskId: Int): Flow<Task?> {
        return repository.getTaskById(taskId)
    }

    /**
     * Insert new task.
     */
    fun insertTask(task: Task) {
        viewModelScope.launch {
            repository.insertTask(task)
        }
    }

    /**
     * Update existing task.
     */
    fun updateTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    /**
     * Delete task.
     * Called by Swipe-to-Delete feature.
     */
    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }
}

/**
 * Factory to create TaskViewModel with dependencies.
 */
class TaskViewModelFactory(
    private val repository: TaskRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            return TaskViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}