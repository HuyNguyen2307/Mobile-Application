package com.example.uniplanner.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Main database class for the app.
 *
 * Singleton Pattern ensures only ONE database instance exists.
 * Why Singleton?
 * 1. Database connections are expensive to create
 * 2. Multiple instances could cause data corruption
 * 3. Consistent data access throughout the app
 */
@Database(
    entities = [Task::class],
    version = 1,
    exportSchema = false  // Set true in production for migrations
)
abstract class AppDatabase : RoomDatabase() {

    // Room auto-generates implementation of this
    abstract fun taskDao(): TaskDao

    companion object {
        // @Volatile ensures all threads see the latest value
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Get database instance using double-checked locking.
         * Thread-safe singleton creation.
         */
        fun getDatabase(context: Context): AppDatabase {
            // First check (no locking) - fast path
            return INSTANCE ?: synchronized(this) {
                // Second check (with locking) - safe path
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "uniplanner_database"
                )
                    .fallbackToDestructiveMigration()  // Dev only! Recreates DB on version change
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}